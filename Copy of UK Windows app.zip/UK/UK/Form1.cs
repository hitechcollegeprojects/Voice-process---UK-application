﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace UK
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s = ConfigurationManager.ConnectionStrings["UK"].ConnectionString;
            SqlConnection con = new SqlConnection(s);
            string query = "select * from Login where username=@user and password=@pass";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@user", textBox1.Text);
            cmd.Parameters.AddWithValue("@pass", textBox2.Text);
            con.Open();
            SqlDataReader d = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(d);
            con.Close();
            if (dt.Rows.Count > 0)
            {
                string role = dt.Rows[0]["role"].ToString();

                if (role.Equals("Admin"))
                {
                    this.Hide();
                    Form2 admin = new Form2();
                    admin.Show();
                }
                else if (role.Equals("Doctor"))
                {
                    this.Hide();
                    Form3 doctor = new Form3();
                    doctor.Show();
                }
                else if (role.Equals("Trancsriber"))
                {
                    this.Hide();
                    Form4 transcriber = new Form4();
                    transcriber.Show();
                }
            }
            else
            {
                MessageBox.Show("Invalid Username and Password");
            }
            
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            bool check = checkBox1.Checked;
            switch (check)
            {
                case true:
                    textBox2.UseSystemPasswordChar = false;
                    break;
                default:
                    textBox2.UseSystemPasswordChar = true;
                    break;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackgroundImage = Image.FromFile("E:\\he2.jpg");
            this.BackgroundImageLayout = ImageLayout.Stretch;
            TransparetBackground(label1);
            TransparetBackground(label2);
            TransparetBackground(label3);
            TransparetBackground(checkBox1);
        }
        void TransparetBackground(Control C)
        {
            C.Visible = false;

            C.Refresh();
            Application.DoEvents();

            Rectangle screenRectangle = RectangleToScreen(this.ClientRectangle);
            int titleHeight = screenRectangle.Top - this.Top;
            int Right = screenRectangle.Left - this.Left;

            Bitmap bmp = new Bitmap(this.Width, this.Height);
            this.DrawToBitmap(bmp, new Rectangle(0, 0, this.Width, this.Height));
            Bitmap bmpImage = new Bitmap(bmp);
            bmp = bmpImage.Clone(new Rectangle(C.Location.X + Right, C.Location.Y + titleHeight, C.Width, C.Height), bmpImage.PixelFormat);
            C.BackgroundImage = bmp;

            C.Visible = true;
        }
    }
}
