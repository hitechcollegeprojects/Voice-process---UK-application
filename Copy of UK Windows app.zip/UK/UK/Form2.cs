﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace UK
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }
        void TransparetBackground(Control C)
        {
            C.Visible = false;

            C.Refresh();
            Application.DoEvents();

            Rectangle screenRectangle = RectangleToScreen(this.ClientRectangle);
            int titleHeight = screenRectangle.Top - this.Top;
            int Right = screenRectangle.Left - this.Left;

            Bitmap bmp = new Bitmap(this.Width, this.Height);
            this.DrawToBitmap(bmp, new Rectangle(0, 0, this.Width, this.Height));
            Bitmap bmpImage = new Bitmap(bmp);
            bmp = bmpImage.Clone(new Rectangle(C.Location.X + Right, C.Location.Y + titleHeight, C.Width, C.Height), bmpImage.PixelFormat);
            C.BackgroundImage = bmp;

            C.Visible = true;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.BackgroundImage = Image.FromFile("E:\\he2.jpg");
            this.BackgroundImageLayout = ImageLayout.Stretch;
            TransparetBackground(label1);
            TransparetBackground(label2);
            TransparetBackground(label3);
            TransparetBackground(label4);
            TransparetBackground(label5);
            
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            comboBox1.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s = ConfigurationManager.ConnectionStrings["UK"].ConnectionString;
            SqlConnection con = new SqlConnection(s);
            string query = "insert into Login values(@user,@pass,@role)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@user", textBox1.Text);
            cmd.Parameters.AddWithValue("@pass", textBox2.Text);
            cmd.Parameters.AddWithValue("@role", comboBox1.SelectedItem);
            con.Open();
            int a = cmd.ExecuteNonQuery();
            if(a>0)
            {
                MessageBox.Show("Insertion Successfully");
                dataGridView1.Visible = true;
                gridview();
            }
            else
            {
                MessageBox.Show("Insertion Failed");
            }
            con.Close();
        }

        public void gridview()
        {
            string s = ConfigurationManager.ConnectionStrings["UK"].ConnectionString;
            SqlConnection con = new SqlConnection(s);
            string query = "Select * from Login";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            DataTable data = new DataTable();
            sda.Fill(data);
            dataGridView1.DataSource = data;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            gridview();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string s = ConfigurationManager.ConnectionStrings["UK"].ConnectionString;
            SqlConnection con = new SqlConnection(s);
            string query = "Update Login set username=@user,password=@pass,role=@role where username=@user";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@user", textBox1.Text);
            cmd.Parameters.AddWithValue("@pass", textBox2.Text);
            cmd.Parameters.AddWithValue("@role", comboBox1.SelectedItem);
            con.Open();
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {
                MessageBox.Show("Update Successfully");
                dataGridView1.Visible = true;
                gridview();
            }
            else
            {
                MessageBox.Show("Updation Failed");
            }
            con.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string s = ConfigurationManager.ConnectionStrings["UK"].ConnectionString;
            SqlConnection con = new SqlConnection(s);
            string query = "delete from Login where username=@user";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@user", textBox1.Text);
            con.Open();
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {
                MessageBox.Show("Delete Successfully");
                dataGridView1.Visible = true;
                gridview();
            }
            else
            {
                MessageBox.Show("Deletion Failed");
            }
            con.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 login = new Form1();
            login.Show();
        }
    }
}
